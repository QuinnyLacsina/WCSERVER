var http = require('http'); 
var root = require('./root.js');
var about = require('./about.js');
var contact = require('./contact.js');
var user = 'John Smith';

var server = http.createServer(function(req, res){ 
    if (req.url == '/') { 

        res.writeHead(200, { 'Content-Type': 'text/html'});

        res.write('<html><body><h1>Welcome to my Node.js Application</h1></body></html>');
        res.write(root(user));
        res.end();
    }

    else if (req.url == "/about"){

        res.writeHead(200, { 'Content-Type': 'text/html'});
        res.write('<html><body><h2>This is the About Page</h2></body></html>');
        res.write(about(user));
        res.end();
    }

    else if (req.url == '/contact') {

        res.writeHead(200, { 'Content-Type': 'text/html'});
        res.write('<html><body><h3>This is the Contact Page</h3></body></html>');
        res.write(contact(user));
        res.end();
    }

    else if (req.url == '/gallery') {

      res.writeHead(200, { 'Content-Type': 'text/html'});
      res.write('<html><body><h3>This is the Gallery Page</h3></body></html>');
      res.end();
  }

    else
        res.end('Invalid Request');

    

});

server.listen(5200);
console.log('NodeJS web server at port 5200 is running...')

//Quinny Joyce Ann M. Lacsina
//January 28, 2022
//WD-201