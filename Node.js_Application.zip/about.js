module.exports = function(user) {
  var content1 = 'Hello';
  var content2 = 'This activity will teach on how to deal with a simple server and local modules in Node.js'
  return content1 + ' ' + user + '. ' + content2;
}