module.exports = function(user) {
  var content1 = ' if you want additional details about this activity go to this site: https://www.tutorialsteacher.com/nodejs/nodejs-tutorials';
  return user + ', ' + content1;
}