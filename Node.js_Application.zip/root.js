module.exports = function(user) {
  var content1 = 'Welcome';
  var content2 = 'This is an activity about basics of Node.js'
  return content1 + ' ' + user + '. ' + content2;
}